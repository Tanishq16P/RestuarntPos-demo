-- SQL schema and seed data
CREATE DATABASE IF NOT EXISTS restaurant_db;
USE restaurant_db;
-- (rest of schema and inserts here)
